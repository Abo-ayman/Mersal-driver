import 'dart:async';

import 'package:flutter/material.dart';

import '../config.dart';
import '../core/logo.dart';
import '../core/push.dart';
import '../core/theme.dart';
import '../data/staff_repository.dart';
import 'login_screen.dart';
import 'order_detail_screen.dart';

const _tabs = <(String, List<String>)>[
  ('جديدة', ['awaiting_review', 'pending_driver']),
  ('بانتظار الزبون', ['awaiting_customer_approval']),
  ('قيد التنفيذ', ['processing', 'ready', 'on_the_way']),
  ('السجل', ['delivered', 'rejected', 'cancelled']),
];

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  Timer? _timer;
  int _tick = 0;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: AppConfig.refreshSeconds),
        (_) => setState(() => _tick++));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _logout() async {
    await Push.unregister();
    await StaffRepository().signOut();
    if (!mounted) return;
    Navigator.of(context)
        .pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: _tabs.length,
      child: Scaffold(
        appBar: AppBar(
          title: const MersalLogo(markSize: 30, horizontal: true),
          actions: [
            IconButton(onPressed: _logout, icon: const Icon(Icons.logout), tooltip: 'خروج'),
          ],
          bottom: TabBar(
            isScrollable: true,
            labelColor: Brand.primary,
            indicatorColor: Brand.primary,
            tabs: [for (final t in _tabs) Tab(text: t.$1)],
          ),
        ),
        body: TabBarView(
          children: [
            for (final t in _tabs) _OrderList(key: ValueKey('${t.$1}$_tick'), statuses: t.$2),
          ],
        ),
      ),
    );
  }
}

class _OrderList extends StatefulWidget {
  final List<String> statuses;
  const _OrderList({super.key, required this.statuses});

  @override
  State<_OrderList> createState() => _OrderListState();
}

class _OrderListState extends State<_OrderList> {
  late Future<List<Map<String, dynamic>>> _future = StaffRepository().orders(widget.statuses);

  void _reload() => setState(() => _future = StaffRepository().orders(widget.statuses));

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => _reload(),
      child: FutureBuilder<List<Map<String, dynamic>>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return ListView(children: [
              const SizedBox(height: 120),
              const Center(child: Text('تعذر تحميل الطلبات')),
              Center(child: TextButton(onPressed: _reload, child: const Text('إعادة المحاولة'))),
            ]);
          }
          final orders = snap.data!;
          if (orders.isEmpty) {
            return ListView(children: const [
              SizedBox(height: 120),
              Center(child: Text('لا توجد طلبات')),
            ]);
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: orders.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (_, i) {
              final o = orders[i];
              final d = customDetails(o);
              final isCustom = o['type'] == 'custom';
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  title: Text(
                    isCustom ? (d?['item_name'] ?? 'طلب خاص') : 'طلب #${o['order_number']}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    '#${o['order_number']} · ${o['customer_name'] ?? 'زبون'}\n${statusAr[o['status']] ?? o['status']}',
                  ),
                  isThreeLine: true,
                  trailing: isCustom
                      ? const Chip(label: Text('اطلب أي شيء'))
                      : null,
                  onTap: () async {
                    await Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => OrderDetailScreen(orderId: o['id'])));
                    _reload();
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
