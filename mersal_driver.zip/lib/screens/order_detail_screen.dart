import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/theme.dart';
import '../data/routing_service.dart';
import '../data/staff_repository.dart';

class OrderDetailScreen extends StatefulWidget {
  final String orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final _repo = StaffRepository();
  final RoutingService _routing = OsrmRoutingService();

  Map<String, dynamic>? _order;
  Map<String, dynamic>? _settings;
  Object? _loadError;

  final _price = TextEditingController();
  final _distance = TextEditingController();
  final _note = TextEditingController();
  Map<String, dynamic>? _fee;
  bool _calcBusy = false;
  bool _busy = false;
  String? _routeMsg;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final o = await _repo.order(widget.orderId);
      _settings ??= await _repo.pricingSettings();
      if (!mounted) return;
      setState(() {
        _order = o;
        _loadError = null;
      });
      final status = o['status'] as String;
      if (o['type'] == 'custom' &&
          (status == 'awaiting_review' || status == 'awaiting_customer_approval')) {
        final d = customDetails(o);
        if (_price.text.isEmpty && d?['quoted_price'] != null) {
          _price.text = '${d!['quoted_price']}';
        }
        if (_distance.text.isEmpty) {
          if (o['route_distance_m'] != null) {
            _distance.text = '${o['route_distance_m']}';
            _previewFee();
          } else {
            _calcRoute();
          }
        }
      }
    } catch (e) {
      if (mounted) setState(() => _loadError = e);
    }
  }

  void _msg(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _calcRoute() async {
    final o = _order!;
    final s = _settings!;
    if (o['delivery_lat'] == null || o['delivery_lon'] == null) {
      setState(() => _routeMsg = 'موقع الزبون غير متوفر');
      return;
    }
    setState(() {
      _calcBusy = true;
      _routeMsg = null;
    });
    final m = await _routing.drivingDistanceMeters(
      fromLat: (s['center_lat'] as num).toDouble(),
      fromLon: (s['center_lon'] as num).toDouble(),
      toLat: (o['delivery_lat'] as num).toDouble(),
      toLon: (o['delivery_lon'] as num).toDouble(),
    );
    if (!mounted) return;
    setState(() => _calcBusy = false);
    if (m == null) {
      setState(() => _routeMsg =
          'تعذر حساب مسافة الطريق. أعد المحاولة أو أدخل المسافة يدوياً بقرارك.');
      return;
    }
    _distance.text = '$m';
    _previewFee();
  }

  Future<void> _previewFee() async {
    final m = int.tryParse(_distance.text.trim());
    if (m == null) {
      setState(() => _fee = null);
      return;
    }
    try {
      final f = await _repo.feePreview(m);
      if (mounted) setState(() => _fee = f);
    } catch (_) {
      if (mounted) setState(() => _fee = null);
    }
  }

  Future<void> _sendQuote() async {
    final price = num.tryParse(_price.text.trim());
    final dist = int.tryParse(_distance.text.trim());
    if (price == null || price < 0) return _msg('اكتب سعر السلعة');
    if (dist == null) return _msg('مسافة الطريق مطلوبة');
    setState(() => _busy = true);
    try {
      final res = await _repo.quote(
        orderId: widget.orderId,
        itemPrice: price,
        routeDistanceM: dist,
        note: _note.text.trim().isEmpty ? null : _note.text.trim(),
      );
      _msg('أُرسل العرض للزبون. الإجمالي ${res['total']} ل.ت');
      await _load();
    } catch (e) {
      _msg(friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _change(String to, {bool askReason = false}) async {
    String? reason;
    if (askReason) {
      final c = TextEditingController();
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('السبب'),
          content: TextField(
              controller: c, decoration: const InputDecoration(hintText: 'اكتب السبب')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('رجوع')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأكيد')),
          ],
        ),
      );
      if (ok != true) return;
      reason = c.text.trim().isEmpty ? null : c.text.trim();
    }
    setState(() => _busy = true);
    try {
      await _repo.changeStatus(widget.orderId, to, reason: reason);
      await _load();
    } catch (e) {
      _msg(friendlyError(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _open(Uri uri, {Uri? fallback}) async {
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    } catch (_) {}
    if (fallback != null) {
      try {
        await launchUrl(fallback, mode: LaunchMode.externalApplication);
        return;
      } catch (_) {}
    }
    _msg('تعذر فتح التطبيق');
  }

  Widget _row(String k, String v, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Text(k),
          const Spacer(),
          Flexible(
              child: Text(v,
                  textAlign: TextAlign.end,
                  style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500))),
        ]),
      );

  Widget _section(String title, List<Widget> children) => Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 8),
            ...children,
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (_loadError != null) {
      return Scaffold(
          appBar: AppBar(title: const Text('تفاصيل الطلب')),
          body: Center(
              child: TextButton(onPressed: _load, child: const Text('تعذر التحميل، أعد المحاولة'))));
    }
    final o = _order;
    if (o == null) {
      return Scaffold(
          appBar: AppBar(title: const Text('تفاصيل الطلب')),
          body: const Center(child: CircularProgressIndicator()));
    }
    final d = customDetails(o);
    final status = o['status'] as String;
    final isCustom = o['type'] == 'custom';
    final lat = o['delivery_lat'] as num?;
    final lon = o['delivery_lon'] as num?;
    final phone = o['customer_phone'] as String?;
    final canQuote = isCustom && (status == 'awaiting_review' || status == 'awaiting_customer_approval');
    final quoted = d?['quoted_price'] != null;

    return Scaffold(
      appBar: AppBar(title: Text('طلب #${o['order_number']}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
                color: Brand.primary.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(14)),
            child: Text(statusAr[status] ?? status,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          const SizedBox(height: 12),
          _section('الزبون والتوصيل', [
            _row('الاسم', '${o['customer_name'] ?? '-'}'),
            _row('الهاتف', phone ?? '-'),
            _row('العنوان', '${o['delivery_address'] ?? '-'}'),
            if ((o['customer_notes'] ?? '').toString().isNotEmpty)
              _row('ملاحظات الزبون', '${o['customer_notes']}'),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: phone == null ? null : () => _open(Uri.parse('tel:$phone')),
                  icon: const Icon(Icons.call),
                  label: const Text('اتصال'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: (lat == null || lon == null)
                      ? null
                      : () => _open(Uri.parse('geo:$lat,$lon?q=$lat,$lon'),
                          fallback: Uri.parse(
                              'https://www.google.com/maps/search/?api=1&query=$lat,$lon')),
                  icon: const Icon(Icons.map_outlined),
                  label: const Text('فتح الموقع'),
                ),
              ),
            ]),
          ]),
          if (isCustom && d != null) ...[
            const SizedBox(height: 12),
            _section('الطلب الخاص', [
              Text('${d['item_name']}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              if ((d['description'] ?? '').toString().isNotEmpty) Text('${d['description']}'),
              _row('الكمية', '${d['quantity']}'),
              if ((d['suggested_store'] ?? '').toString().isNotEmpty)
                _row('متجر مقترح', '${d['suggested_store']}'),
              if (d['image_url'] != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(d['image_url'], height: 170, fit: BoxFit.cover)),
                ),
            ]),
          ],
          if (canQuote) ...[
            const SizedBox(height: 12),
            _section('تسعير الطلب', [
              TextField(
                controller: _price,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'سعر السلعة (ل.ت)'),
              ),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: TextField(
                    controller: _distance,
                    keyboardType: TextInputType.number,
                    onChanged: (_) => _previewFee(),
                    decoration: const InputDecoration(labelText: 'مسافة الطريق (متر)'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  onPressed: _calcBusy ? null : _calcRoute,
                  icon: _calcBusy
                      ? const SizedBox(
                          height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.route),
                  tooltip: 'احسب من الخريطة',
                ),
              ]),
              if (_routeMsg != null)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(_routeMsg!, style: const TextStyle(color: Colors.orange)),
                ),
              const SizedBox(height: 10),
              if (_fee != null) ...[
                _row('التوصيل الأساسي', '${_fee!['base_fee']} ل.ت'),
                if ((_fee!['distance_fee'] as num) > 0)
                  _row('رسوم المسافة', '${_fee!['distance_fee']} ل.ت'),
                if ((_fee!['time_fee'] as num) > 0)
                  _row(_fee!['time_fee_kind'] == 'night' ? 'رسوم ليلية VIP' : 'رسوم مسائية',
                      '${_fee!['time_fee']} ل.ت'),
                _row('إجمالي التوصيل', '${_fee!['delivery_total']} ل.ت', bold: true),
                if (num.tryParse(_price.text.trim()) != null)
                  _row('الإجمالي للزبون',
                      '${num.parse(_price.text.trim()) + (_fee!['delivery_total'] as num)} ل.ت',
                      bold: true),
              ],
              const SizedBox(height: 10),
              TextField(
                controller: _note,
                maxLines: 2,
                decoration: const InputDecoration(labelText: 'ملاحظة للزبون (اختياري)'),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: _busy ? null : _sendQuote,
                child: Text(quoted ? 'تحديث العرض وإرساله' : 'إرسال العرض للزبون'),
              ),
              const SizedBox(height: 6),
              const Text(
                  'الرسوم الزمنية تُحسب وقت موافقة الزبون، وقد تختلف عن المعروض هنا إن تغيّر الوقت.',
                  style: TextStyle(fontSize: 12, color: Colors.black54)),
            ]),
          ] else if (quoted) ...[
            const SizedBox(height: 12),
            _section('الفاتورة', [
              _row('قيمة المنتجات', '${o['items_subtotal']} ل.ت'),
              _row('التوصيل', '${o['delivery_total']} ل.ت'),
              _row('الإجمالي', '${o['total']} ل.ت', bold: true),
              _row('الدفع', 'نقداً عند الاستلام'),
              if (o['route_distance_m'] != null) _row('مسافة الطريق', '${o['route_distance_m']} م'),
            ]),
          ],
          const SizedBox(height: 16),
          ..._actions(status),
        ],
      ),
    );
  }

  List<Widget> _actions(String status) {
    Widget big(String label, String to, {Color? color}) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: FilledButton(
            style: color == null ? null : FilledButton.styleFrom(backgroundColor: color),
            onPressed: _busy ? null : () => _change(to),
            child: Text(label),
          ),
        );
    Widget outline(String label, String to) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
            onPressed: _busy ? null : () => _change(to, askReason: true),
            child: Text(label),
          ),
        );
    switch (status) {
      case 'awaiting_review':
        return [outline('رفض الطلب', 'rejected')];
      case 'pending_driver':
        return [big('قبول الطلب', 'processing'), outline('رفض الطلب', 'rejected')];
      case 'processing':
        return [big('تم التجهيز، جاهز للتوصيل', 'ready'), outline('إلغاء الطلب', 'cancelled')];
      case 'ready':
        return [big('أنا في الطريق', 'on_the_way', color: Brand.accent), outline('إلغاء الطلب', 'cancelled')];
      case 'on_the_way':
        return [big('تم التسليم', 'delivered', color: Brand.accent), outline('إلغاء الطلب', 'cancelled')];
      case 'awaiting_customer_approval':
        return [outline('إلغاء الطلب', 'cancelled')];
      default:
        return [];
    }
  }
}
