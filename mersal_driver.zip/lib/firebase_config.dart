import 'package:firebase_core/firebase_core.dart';

/// Fill these four values from this app's google-services.json
/// (apiKey = client[0].api_key[0].current_key, appId = client[0].client_info.mobilesdk_app_id,
///  messagingSenderId = project_info.project_number, projectId = project_info.project_id).
/// While empty, push notifications are simply disabled and the app works normally.
class FirebaseConfig {
  static const apiKey = 'AIzaSyAQsskNmZl19--uM503MZn-p3nUJuThMfY';
  static const appId = '1:104127923642:android:7cebe2a529e570516e4983';
  static const messagingSenderId = '104127923642';
  static const projectId = 'mersal-delivery-2687a';

  static bool get enabled =>
      apiKey.isNotEmpty && appId.isNotEmpty && messagingSenderId.isNotEmpty && projectId.isNotEmpty;

  static FirebaseOptions get options => const FirebaseOptions(
        apiKey: apiKey,
        appId: appId,
        messagingSenderId: messagingSenderId,
        projectId: projectId,
      );
}
